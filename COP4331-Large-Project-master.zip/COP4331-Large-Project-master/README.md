# Queue & A

Queue & A allows students to ask the professor questions during a lecture (especially during classes with extremely large lectures or hybrid classes that have streamed lectures). The goal is to allow students to ask questions without stopping the professor mid-lecture, so the professor can answer any questions when they feel it’s most appropriate. Additionally, this will be useful for any students who do not feel comfortable asking questions in a large class.

Developed for COP4331 (Processes for Object Oriented Software Development), by Matthew Garrison, Warren Atchison, Shane Rhoads, Kobee Raveendran, Nestor Montejo, Julia Berger, and Thomas Anchor.
